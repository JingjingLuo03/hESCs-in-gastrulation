#Code description:

"Pseudotime.R" is used to reconstruct cell differentiation trajectories.
"Network.R" is  used to construct gene regulatory networks.
"HITS.R" calculates the hub and authority values of nodes.